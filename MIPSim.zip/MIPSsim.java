import java.nio.file.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

class Instruction{
    public int add;
    public String opcode;
    public int rd;
    public int rs;
    public int rt;
    public int offset;
    public String ins;

    public Instruction() {
    }
    
    public Instruction(int a, String s,int dv, int sv, int tv,String si){
        this.add = a;this.opcode = s;this.rd = dv;this.rs = sv;this.rt = tv;this.ins = si;
    }
     
    public Instruction(int a, String s,int dv, int sv, int tv,int o,String si){
        this.add = a;this.opcode = s;this.rd = dv;this.rs = sv;this.rt = tv;this.offset = o;this.ins = si;
    }
}

class RSEntry{
    public int addr;
    public String ins;
    public boolean busy;
    public String op;
    public int Vj;
    public int Vk;
    public int Qj;
    public int Qk;
    public int Dest;
    public int A;
    public int result;
    
    public RSEntry(){
        this.addr = -1;
        this.ins = null;
        this.busy = false;
        this.op = null;
        this.Vj = -1;
        this.Vk = -1;
        this.Qj = -1;
        this.Qk = -1;
        this.Dest = -1;
        this.A = -1;
    }
    
    public RSEntry(boolean b,String o,int vj,int vk,int qj,int qk,int dest,int A){
        this.busy = b;this.op = o;this.Vj = vj;this.Vk = vk;
        this.Qj = qj;this.Qk = qk;this.Dest = dest;this.A = A;
    }

       
    public void PrintRS(){
        System.out.println("rsaddr:"+addr+"  ins:"+ins+"  busy:"+busy+
                "  op:"+op+"  Vj:"+Vj+"  Vk:"+Vk+"  Qj:"+Qj+" Qk:"+Qk+" Dest:"+Dest+
                " A:"+A+" result:"+result);
    } 
}

class ROBEntry{
    public int addr;
    public boolean busy;
    public String ins;
    public String state;
    public int Dest;
    public int value;
    public boolean Ready;

    public ROBEntry(boolean busy, String ins, String state, int Dest, int value) {
        this.busy = busy;
        this.ins = ins;
        this.state = state;
        this.Dest = Dest;
        this.value = value;
    }

    ROBEntry() {
        this.addr = -1;
        this.busy = false;
        this.ins = null;
        this.state = null;
        this.Dest = -1;
        this.value = -1;
        this.Ready = false;
    }

      
    public void PrintROB(){
        System.out.println("addr:"+addr+"  busy:"+busy+"  ins:"+ins+"  state:"+state+"  Dest:"+Dest+"  value:"+value+"  Ready:"+Ready);
    }
  
}

class RegisterStat{
    public int reorder;
    public boolean busy;

    
    RegisterStat(){
        reorder = -1;
        busy = false;
    }
    
    public RegisterStat(int reorder, boolean busy) {
        this.reorder = reorder;
        this.busy = busy;
    }
    
    public void PrintRegisterStat(){
        System.out.println("reorder:"+reorder+"  busy:"+busy);
    }
}

class BTBEntry{
    public String op;
    public int source;
    public int target;
    public int taken;
    
    BTBEntry(){
        op = "";
        source = -1;
        target = -1;
        taken = -1;
    }

    public BTBEntry(int source, int target, int taken) {
        this.source = source;
        this.target = target;
        this.taken = taken;
    }
    
    public String PrintBTB(){
         return "<"+this.source+","+this.target+","+this.taken+">";
    }
    
}
public class MIPSsim {
                      // 0     1   2    3     4     5      6      7       8      9      10
	String [] oc = {"SW","LW","J","BEQ","BNE","BGEZ","BGTZ","BLEZ","ADDI","ADDIU","SLTI"};
	                // 0     1    2     3       4     5      6     7     8     9     10     11    12     13
	String [] soc = {"NOR","XOR","OR","BREAK","SLT","SLTU","SLL","SRL","SRA","SUB","SUBU","ADD","ADDU","AND"};
	
	String [] sbn = {"100111","100110","100101","001101","101010","101011","000000","000010","000011","100010","100011",
			"100000","100001","100100"};
	
	String [] bn = {"101011","100011","000010","000100","000101","000001","000111","000110",
			"001000","001001","001010"};
	/////////////////////////////---------------------------------/////////////////////////////// operations       
        static LinkedList<Instruction> Inst = new LinkedList<>();
        static LinkedList<ROBEntry> ROB = new LinkedList<>();
        static LinkedList<RSEntry> RS = new LinkedList<>(); 
        RegisterStat[] regstat = new RegisterStat[32];
        int[] regfile = new int[32];
        int[] dataseg = new int[10];
        List<Instruction> fetchqueue = new LinkedList<>();
        List<BTBEntry> BTB = new LinkedList<>();
        //////////data structures/////////////
        
        int commitcount = 0;
        boolean jumpcommited = false;
        boolean breakcommited = false;
        int pcounter = 600;
	List<String> bnstr;
        int val = 0;
	int address = 600;
	int count = 0;
	String zerostr = "00000000000000000000000000000000";
        static int cycle = 1;
        public int Jmiss = 1,BEQmiss = 1; 
        /////////variables used//////
        
       MIPSsim(){
           for (int i = 0;i<regfile.length;i++)
               regfile[i] = 0;
           for (int j = 0;j<dataseg.length;j++)
               dataseg[j] = 0;
           for (int k = 0;k<regstat.length;k++)
               regstat[k] = new RegisterStat();
       }
       
       public Instruction getInstruction(int add){
           Instruction i = new Instruction();
           for (Instruction j : Inst){
               if (j.add == add)
                   return j;
           }
           return i;
       }
       
       public BTBEntry getBTBAction(int add){
           for (BTBEntry btb : BTB){
               if (btb.source == add){
                   return btb;
                }
           }
           return new BTBEntry();
       }
         
       
       public void Fetch(){
           System.out.println(jumpcommited+"=jc");
           if (pcounter < 716 && !jumpcommited){
                fetchqueue.add(getInstruction(pcounter));
                if (getInstruction(pcounter).opcode.equals("BEQ")){
                     if (getBTBAction(pcounter).taken == 1){
                         pcounter = getBTBAction(pcounter).target-4;
                     }   
                     pcounter = pcounter + 4;
                }
                else if (getInstruction(pcounter).opcode.equals("J")){
                     if (getBTBAction(pcounter).taken == 1){
                         pcounter = getBTBAction(pcounter).target - 4;
                     }
                     pcounter = pcounter + 4;
                }
                else if (getInstruction(pcounter).opcode.equals("BREAK")){
                     pcounter = 999;
                }
                else 
                    pcounter = pcounter + 4;
           }
        }
       
       public void IssueandDecode(Instruction in){
        
            int Robpos = 0;
            RSEntry temp;
            System.out.println(commitcount);
            if ( (RS.size() >= 6 && ROB.size() >= 6) || (commitcount == 1 && RS.size() == 5 && ROB.size() == 5)){
               System.out.println("issues with the ROB & RS");
               return ;
            }
           else{
               RS.add(new RSEntry());
               ROB.add(new ROBEntry());
                                       
                if (regstat[in.rs].busy){
                    Robpos = regstat[in.rs].reorder;
                    if (ROB.get(Robpos).Ready){
                        RS.get(RS.size() - 1).Vj = ROB.get(Robpos).value;
                        RS.get(RS.size() - 1).Qj = -1;
                    }else{
                        RS.get(RS.size() - 1).Qj = Robpos;
                    }
                }
                else{
                    RS.get(RS.size() - 1).Vj = regfile[in.rs];
                    RS.get(RS.size() - 1).Qj = -1;
                }
               
               switch (in.opcode){
                   case "ADD" :
                   case "ADDU":
                   case "SUB" :
                   case "SUBU":
                   
                        regstat[in.rd].reorder = ROB.size() - 1;
                       regstat[in.rd].busy = true;
                       ROB.get(ROB.size() - 1).Dest = in.rd;
                   case "SW"  :
                   case "BEQ" :
                   case "BNE" :
                   case "XQR":
                   case "BGEZ":
                   case "BJTZ" :
                   case "BLEZ" :
                   case "BLTZ" :
                   case "NOR" :
                   case "AND":
                   case "OR" :
                   case "SLT":
                   
                   
                       if(regstat[in.rt].busy){
                            Robpos = regstat[in.rt].reorder;
                            if (ROB.get(Robpos).Ready){
                                RS.get(RS.size() - 1).Vk = ROB.get(Robpos).value;
                                RS.get(RS.size() - 1).Qk = -1;
                            }else{
                                RS.get(RS.size() - 1).Qk = Robpos;
                            }
                        }
                        else{
                        RS.get(RS.size() - 1).Vk = regfile[in.rt];
                        RS.get(RS.size() - 1).Qk = -1;
                        }
                       RS.get(RS.size() - 1).A = in.offset;
                    break;
                    
                   case "ADDI"  :
                   case "LW" :
                        RS.get(RS.size() - 1).A = in.offset;
                        regstat[in.rt].reorder = ROB.size() - 1;
                        regstat[in.rt].busy = true;
                        ROB.get(ROB.size() - 1).Dest = in.rt;
                    break;
                    
                   case "BREAK" :
                   case "NOP" :
                       temp = RS.removeLast();
                       ROB.get(ROB.size() - 1).state = "written";
                       ROB.get(ROB.size()-1).Ready = true;
              
                    break;   
                }
            
           if (!in.opcode.equals("NOP") && !in.opcode.equals("BREAK")){
                RS.get(RS.size() - 1).addr = in.add;
                RS.get(RS.size() - 1).ins = in.ins;
                RS.get(RS.size() - 1).busy = true;
                RS.get(RS.size() - 1).op = in.opcode;
                RS.get(RS.size() - 1).Dest = ROB.size() - 1;
                //////setting RS////
           }
                      
           ROB.get(ROB.size() - 1).addr = in.add;
           ROB.get(ROB.size() - 1).busy = true;
           ROB.get(ROB.size() - 1).ins = in.ins;
           if (!in.opcode.equals("NOP") && !in.opcode.equals("BREAK")){
                ROB.get(ROB.size() - 1).state = "issue";
           ROB.get(ROB.size() - 1).Ready = false;}
           /////setting ROB/////
                      
           if (in.opcode.equals("J"))
               RS.get(RS.size() - 1).A = in.offset;
               
           fetchqueue.remove(0);
           
        }
       }
       
       
       public boolean CheckStore(RSEntry r){
           int index = RS.indexOf(r);
           int i = 0;
           while(i < index){
               if(RS.get(i).op.equals("SW") || RS.get(i).op.equals("LW")){
                   if (RS.get(i).Qj != -1)
                       return true;
               }
               i++;
           }
           return false;
       }
       
       public boolean CheckStoreAdd(RSEntry e){
           int index = RS.indexOf(e);
           int i = 0;
           while(i < index){
               if(RS.get(i).op.equals("SW")){
                   if (RS.get(i).Qj != -1 && e.A == RS.get(i).A)
                       return true;
               }
               i++;
           }
           return false;
       }
       
       public String getState(RSEntry e){
           for (ROBEntry rob : ROB){
               if (rob.addr == e.addr)
                   return rob.state;
           }
           return "";
       }
       public void setState(RSEntry e, String state){
           for (ROBEntry rob : ROB){
               if (rob.addr == e.addr)
                   rob.state = state;
           }
           
       }
       
       public boolean getROBbusy(RSEntry rse){
           for(ROBEntry rb : ROB)
               if(rse.addr == rb.addr)
                   return rb.busy;
           return false;
       }
       
        public void setROBbusy(RSEntry rse,boolean t){
           for(ROBEntry rb : ROB)
               if(rse.addr == rb.addr)
                   rb.busy = t;
          
           
       }
       
       public void Execute(){
           for (RSEntry rse : RS){
               if (getState(rse).equals("issue") || getState(rse).equals("executedload1")){
                   
                   if (!getROBbusy(rse)){
                       System.out.println(",nn BEQ"+rse.op+" "+getROBbusy(rse));
                    if (rse.op.equals("ADD") || rse.op.equals("ADDI")){
                        if (rse.Qj == -1 && rse.Qk == -1){
                            if (rse.op.equals("ADD")){
                                rse.result = rse.Vj + rse.Vk;
                                setState(rse,"executed");
                            }
                            if (rse.op.equals("ADDI")){
                                rse.result = rse.Vj + rse.A;
                                setState(rse,"executed");
                            }
                        }
                        else{}
                    }
                    else if (rse.op.equals("LW")){
                        if(rse.Qj == -1 && !CheckStore(rse) && getState(rse).equals("issue")){
                            rse.A = rse.Vj + rse.A;
                            setState(rse,"executedload1");
                        }
                        else if(!CheckStoreAdd(rse) && getState(rse).equals("executedload1")){
                            try{
                            rse.result = dataseg[(rse.A - 716)/4];
                            setState(rse,"executed");
                            }catch(Exception e){System.out.println("index array ke bahar ja ra");}
                        }
                        else{
                            //System.out.println("Beta load ka execute is not working");
                        }
                    }
                    else if(rse.op.equals("SW")){
                        if (rse.Qj == -1 && rse.Qk == -1 && getState(rse).equals("issue") && !CheckStore(rse) && !CheckStoreAdd(rse)){
                            rse.A = rse.Vj/4 + rse.A;
                            setDest(rse,rse.A);
                            rse.result = rse.Vk;
                            setValue(rse,rse.result);
                            setReady(rse);
                            setState(rse,"written");
                        }}
                    else if (rse.op.equals("J")){
                            if (BTB.isEmpty())
                                Jmiss = 1;
                            for (BTBEntry btb : BTB){
                                if (btb.source == rse.addr){
                                    Jmiss = 0;
                                    break;
                                }
                                else{
                                    Jmiss = 1;
                                    break;        
                                } 
                                    
                            }
                            setValue(rse,1);
                            setDest(rse,rse.A);
                            setReady(rse);
                            setState(rse,"written");
                        }
                    else if (rse.op.equals("BEQ")){
                        int correct = 0;
                        System.out.println("M here BEQ"+rse.op+" "+getROBbusy(rse));
                        if (rse.Qj == -1 && rse.Qk == -1){
                            if(rse.Vj == rse.Vk)
                                correct = 1;
                            else
			        correct = 0;
							
			    if(BTB.size() == 0 && correct == 1)
                                BEQmiss = 1;
			    else if(BTB.size() == 0 && correct == 0)
				BEQmiss = 0;
			    for(BTBEntry btb: BTB){
				if(btb.source == rse.addr && correct == btb.taken ){
				    BEQmiss = 0;
				    BTB.remove(btb);
				    break;
                                }
                                else if(btb.source == rse.addr && correct != btb.taken ){
				    BEQmiss = 1;
				    BTB.remove(btb);
				    break;				
                                }
                                else if(btb.source != rse.addr && correct == 0 ){
				    BEQmiss = 0;
				    break;				
                                }
                                else if(btb.source != rse.addr && correct == 1 ){
				    BEQmiss = 1;
				    break;				
                                }
								
                            }
			    BTB.add(new BTBEntry(rse.addr,rse.addr+rse.A+4,correct) );
			    setValue(rse,correct);		
			    setDest(rse,rse.addr+rse.A+4);	
			    setReady(rse);			
			    setState(rse,"written");		
                        }
                    }
                        else{
                            //System.out.println("Beta store main kuch issur hai");
                        }
                    }
               setROBbusy(rse,true);
                   }
               
                                    //  System.out.println(getROBbusy(rse)+"=after exe");

           }
           
       }
       
       public void setValue(RSEntry rs,int v){
           for (ROBEntry rob : ROB){
               if (rob.addr == rs.addr)
                   rob.value = v;
           }
       }
       public void setDest(RSEntry rs,int v){
           for (ROBEntry rob : ROB){
               if (rob.addr == rs.addr)
                   rob.Dest = v;
           }
       }
       
       public void setReady(RSEntry rs){
           for (ROBEntry rob : ROB){
               if (rob.addr == rs.addr)
                   rob.Ready = true;
           }
       }
       
       public void WriteBack(){
           int Robpos = 0;
           for (RSEntry rse : RS){
               if (!getROBbusy(rse)){
               if (getState(rse).equals("executed") ){
                    Robpos = rse.Dest;
                    rse.busy = false;
                    for (RSEntry r : RS){
                        if (r.Qj == Robpos){
                            r.Vj = rse.result;
                            r.Qj = -1;
                        }
                        if (r.Qk == Robpos){
                            r.Vk = rse.result;
                            r.Qk = -1;
                        }
                    }
                    if (rse.op.equals("ADDI") || rse.op.equals("ADD") ){
                        setValue(rse,rse.result);
                        setState(rse,"written");
                        setReady(rse);
                    }
                    if ( rse.op.equals("LW") ){
                           setValue(rse,rse.result);
                            setState(rse,"written");
                            setReady(rse);
                    }
                    
                    
           setROBbusy(rse,true);
                    
               }
               }
       }
       }            
       public String getOpcode(ROBEntry rob){
           if(rob.ins.substring(4).equals("NOP")){
               return "NOP";
           }
            if(rob.ins.substring(4).equals("BREAK")){
               return "BREAK";
           }
           for (RSEntry rs:RS){
               if(rs.addr == rob.addr)
                   return rs.op;
           }
           return "";
       }
       public void commit(){
           int d;
           RSEntry rs;ROBEntry rob;
           if (ROB.size() > 0){
               System.out.println("im inside commit ROB size");
               //System.out.println(ROB.size());
                if (ROB.get(0).Ready){
                    System.out.println("im inside commit ROB ready");
                    //System.out.println(ROB.get(0).Ready);
                      // System.out.println(ROB.get(0).busy);
                    if(!ROB.get(0).busy){
                        System.out.println("im inside commit ROB ready"+getOpcode(ROB.get(0)));
                        int pos = 1;
                    //System.out.println(ROB.get(0).busy);
                    commitcount++;
                    d = ROB.get(0).Dest;
                    switch (getOpcode(ROB.get(0))) {
                        
                        case "BREAK":
                            ROB.remove(0);
                            breakcommited = true;
                        break;
                        case "NOP":
                            
                            ROB.remove(0);
                            //System.out.println("insidenop");
                        break;
                        case "BEQ":
                            if(BEQmiss == 1 && ROB.get(0).value == 1){
				pcounter = ROB.get(0).Dest;
				jumpcommited = true;
				while(ROB.size() != 1)
           				ROB.remove(pos);
							
				while(RS.size() != 1)
					RS.remove(pos);
				fetchqueue.clear();
				for(RegisterStat rgs: regstat){
					rgs.reorder = -1;
                                        rgs.busy = false;
				}
                            }
                                else if(BEQmiss == 1 && ROB.get(0).value == 0){
				pcounter = ROB.get(0).addr + 4;
				jumpcommited = true;
				while(ROB.size() != 1)
           				ROB.remove(pos);
							
				while(RS.size() != 1)
					RS.remove(pos);
				fetchqueue.clear();
				for(RegisterStat rgs: regstat){
					rgs.reorder = -1;
                                        rgs.busy = false;
				}
                            }
                        break;
                    case "SW":
                       dataseg[ROB.get(0).Dest - 716] = ROB.get(0).value;
                       break;
                    case "J":
                        //System.out.println("im here jump");
                        if (Jmiss == 1){
                            pcounter = ROB.get(0).Dest;
                          //  System.out.println("counter:"+pcounter+" "+ROB.get(0).Dest);
                            while(ROB.size() != 1)
                                ROB.remove(pos);
                            while(RS.size() != 1)
                                RS.remove(pos);
                            jumpcommited = true;
                        }
                        else{
                            for(BTBEntry btb: BTB){
				if(btb.source == ROB.get(0).addr ){
					BTB.remove(btb);
					break;
				}
			    }
                        }
                        BTB.add(new BTBEntry(ROB.get(0).addr,ROB.get(0).Dest,1));
                        System.out.println("counter:"+pcounter+" domnvftg"+ROB.get(0).Dest);
                    break;
                    default:
                        //System.out.println("insidenopdef");
                       regfile[ROB.get(0).Dest] = ROB.get(0).value;
                       if(regstat[d].reorder == 0)
                           regstat[d].busy = false;
                       break;
                    }
                
                     System.out.println("im out of jump");
                     if(!ROB.isEmpty())
                    rob = ROB.removeFirst();
                    if(!RS.isEmpty())
                     rs = RS.removeFirst();
               
                    for (RSEntry rse : RS){
                        if(rse.Dest > -1)
                            rse.Dest = rse.Dest - 1;
                        if (rse.Qj > -1)
                            rse.Qj = rse.Qj - 1;
                        if (rse.Qk > -1)
                            rse.Qk = rse.Qk - 1;
                    }
                    for (RegisterStat reg : regstat){
                        if (reg.reorder > -1)
                            reg.reorder = reg.reorder - 1;
                    }
                }
                    else{
                    System.out.println("im here else");
                    commitcount = 0;
                }
                }
                
            }
           
       System.out.println(commitcount+"=cc");
       }
       public void PrintCurrentStatus(BufferedWriter bw,int min, int max) throws IOException{
                
           
                    System.out.println("cycle<"+cycle+">");
                    bw.write("cycle<"+cycle+">");
                    bw.newLine();
           
                Fetch();
                System.out.println("IQ:");
                bw.write("IQ:");
                bw.newLine();
                if (!fetchqueue.isEmpty()){
                        int i = 0;
                    while (i < fetchqueue.size()){
                        System.out.println("["+fetchqueue.get(i).ins+"]");
                        bw.write("["+fetchqueue.get(i).ins.substring(3)+"]");
                        bw.newLine();
                        i++;
                    }       
                }
                
                System.out.println("RS:");
                bw.write("RS:");
                bw.newLine();
                for (RSEntry rse : RS){
                    System.out.println("["+rse.ins+"]");
                    bw.write("["+rse.ins.substring(3)+"]");
                    bw.newLine();
                
                    rse.PrintRS();
                }
                System.out.println("ROB:");
                for (ROBEntry rob : ROB){
                    System.out.println("["+rob.ins+"]");
                    bw.write("["+rob.ins.substring(3)+"]");
                    bw.newLine();
                    rob.PrintROB();
                }
                System.out.println("BTB:");
                bw.write("BTB:");
                bw.newLine();
                for (BTBEntry btb : BTB){
                    System.out.println(btb.PrintBTB());
                    bw.write(btb.PrintBTB());
                    bw.newLine();
                }
                System.out.println("Registers:");
                bw.write("Registers");
                bw.newLine();
                for (int i = 0 ; i < regfile.length ; i++){
                System.out.print(regfile[i]+"\t");
                bw.write(regfile[i]+"\t");
                               
                if (i>0 && (i+1)%8 == 0){
                    System.out.println();
                    bw.newLine();
                }
            }
                System.out.println("Data Segament:");
                bw.write("Data Segement");
                System.out.print("716:");
                bw.write("716:");
                    for(int i = 0; i<dataseg.length;i++){
                        System.out.print(dataseg[i]+"\t");
                    bw.write(dataseg[i]+"\t");
                    }
                //System.out.println("Register Status:");
                //for (RegisterStat r : regstat)
                  //  r.PrintRegisterStat();
                System.out.println();
                //WriteBack();
                //Execute();
                //IssueandDecode(fetchqueue.get(0));
                //fetchqueue.remove(0);
                //val++;
           
                cycle++;   
                

                while(!breakcommited){
                       
               
               
                System.out.println("cycle<"+cycle+">");
                bw.write("cycle<"+cycle+">");
                bw.newLine();
           
                jumpcommited = false;
                for(ROBEntry rob : ROB)
                   rob.busy = false; 
                
             
                Execute();
                WriteBack();
                               

                commit();
                if (!fetchqueue.isEmpty())               
                    IssueandDecode(fetchqueue.get(0));
                               

                Fetch();

                System.out.println("IQ:");
                if (!fetchqueue.isEmpty()){
                        int i = 0;
                    while (i < fetchqueue.size()){
                        System.out.println("["+fetchqueue.get(i).ins+"]");
                        i++;
                    }       
                }
                
                System.out.println("RS:");
                bw.write("RS:");
                bw.newLine();
                for (RSEntry rse : RS){
                    System.out.println("["+rse.ins+"]");
                    bw.write("["+rse.ins.substring(3)+"]");
                    bw.newLine();
                
                    rse.PrintRS();
                }
                System.out.println("ROB:");
                for (ROBEntry rob : ROB){
                    System.out.println("["+rob.ins+"]");
                    bw.write("["+rob.ins.substring(3)+"]");
                    bw.newLine();
                    rob.PrintROB();
                }
                System.out.println("BTB:");
                bw.write("BTB:");
                bw.newLine();
                for (BTBEntry btb : BTB){
                    System.out.println(btb.PrintBTB());
                    bw.write(btb.PrintBTB());
                    bw.newLine();
                }
                System.out.println("Registers:");
                bw.write("Registers");
                bw.newLine();
                for (int i = 0 ; i < regfile.length ; i++){
                System.out.print(regfile[i]+"\t");
                bw.write(regfile[i]+"\t");
                               
                if (i>0 && (i+1)%8 == 0){
                    System.out.println();
                    bw.newLine();
                }
            }
                System.out.println("Data Segament:");
                bw.write("Data Segement");
                System.out.print("716:");
                bw.write("716:");
                    for(int i = 0; i<dataseg.length;i++){
                        System.out.print(dataseg[i]+"\t");
                    bw.write(dataseg[i]+"\t");
                    }
                //System.out.println("Register Status:");
                //for (RegisterStat r : regstat)
                  //  r.PrintRegisterStat();
                System.out.println();
                bw.newLine();
               
                cycle++;
            }
           }
       
       
        public void Printregfile(){
            //System.out.println(regfile.length);
            for (int i = 0 ; i < regfile.length ; i++){
                System.out.print(regfile[i]+"\t");
                if (i>0 && (i+1)%8 == 0)
                    System.out.println();
            }
            //System.out.println();
        }
        
        public void Printdataseg(){
            System.out.print("716:");
            for(int i = 0; i<dataseg.length;i++)
                System.out.print(dataseg[i]+"\t");
        }
    
        
  public void binaryReader(String bninst) throws IOException{	

	Path path = FileSystems.getDefault().getPath("",bninst);
	byte [] btins = Files.readAllBytes(path);
	String bnstg = convertBtToBn(btins);
	bnstr = new ArrayList<String>();
	int i = 0;
	while(i < bnstg.length()){
		bnstr.add(bnstg.substring(i, i + 32));
		i += 32;
	}
}
  
  
  
  public String disassemble(String ins){
	  
	  String s,sub1,sub2,sub3,sub4,sub5,sub6,fs,rs,rd,rt,im,sa;
	  sub1 = ins.substring(0, 6);
	  sub2 = ins.substring(6, 11);
	  sub3 = ins.substring(11, 16);
	  sub4 = ins.substring(16, 21);
	  sub5 = ins.substring(21, 26);
	  sub6 = ins.substring(26, 32);
	  s="";
	  fs = sub1 + " " +sub2+" "+sub3+" "+sub4+" "+sub5+" "+sub6+" ";
	  
	  if(ins.equals(zerostr)){
		  if(count ==0){
			  s = address+" NOP";
                          Inst.add(new Instruction(address,"NOP",0,0,0,s));
                  }
                  else{
			  s = address+" 0";
                          //Inst.add(new Instruction(address,"",0,0,0,s));
                  }
		  System.out.println(s);
	  }
	  
	  else if(sub1.equals("000000")){
		  
		  if(sub6.equals(sbn[0])){								
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[0]+" R"+rd+" R"+rs+" R"+rt;
                         Inst.add(new Instruction(address,soc[0],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s));
			  System.out.println(s);
			  
		  }
		  else if(sub6.equals(sbn[1])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[1]+" R"+rd+" R"+rs+" R"+rt;
			 Inst.add(new Instruction(address,soc[1],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
                          System.out.println(s);
		  }
		  else if(sub6.equals(sbn[2])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[2]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[2],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[3])){						
			  s = address+" "+soc[3];
			  count = 1;
                          Inst.add(new Instruction(address,soc[3],0,0,0,s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[4])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[4]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[4],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[5])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[5]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[5],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[6])){						
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  sa = String.valueOf(Integer.parseInt(sub5,2));
			  s = address+" "+soc[6]+" R"+rd+" R"+rt+" "+sa;
                          Inst.add(new Instruction(address,soc[6],Integer.parseInt(rd),Integer.parseInt(sa),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[7])){						
			  sa = String.valueOf(Integer.parseInt(sub5,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[7]+" R"+rd+" R"+rt+" "+sa;
                          Inst.add(new Instruction(address,soc[7],Integer.parseInt(rd),Integer.parseInt(sa),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[8])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[8]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[8],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[9])){						
			  sa = String.valueOf(Integer.parseInt(sub5,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[9]+" R"+rd+" R"+rt+" "+sa;
                          Inst.add(new Instruction(address,soc[9],Integer.parseInt(rd),Integer.parseInt(sa),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[10])){					
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[10]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[10],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[11])){					
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[11]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[11],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[12])){					
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[12]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[12],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
		  else if(sub6.equals(sbn[13])){					
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rd = String.valueOf(Integer.parseInt(sub4,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  s = address+" "+soc[13]+" R"+rd+" R"+rs+" R"+rt;
                          Inst.add(new Instruction(address,soc[13],Integer.parseInt(rd),Integer.parseInt(rs),Integer.parseInt(rt),s)); 
			  System.out.println(s);
		  }
	  }
	  
	  else{
		
		  if(sub1.equals(bn[0])){									
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6;
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[0]+" R"+rt+", "+i+"(R"+rs+")";
                          Inst.add(new Instruction(address,oc[0],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[1])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6;
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[1]+" R"+rt+", "+i+"(R"+rs+")";
                          Inst.add(new Instruction(address,oc[1],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[2])){						
			  im = sub2+sub3+sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[2]+" #"+i;
                          Inst.add(new Instruction(address,oc[2],0,0,0,i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[3])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[3]+" R"+rs+" R"+rt+" #"+i;
                          Inst.add(new Instruction(address,oc[3],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[4])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[4]+" R"+rs+" R"+rt+" #"+i;
                          Inst.add(new Instruction(address,oc[4],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[5])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  im = sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[5]+" R"+rs+" #"+i;
                          Inst.add(new Instruction(address,oc[5],0,Integer.parseInt(rs),0,i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[6])){								
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  im = sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[6]+" R"+rs+" #"+i;
                          Inst.add(new Instruction(address,oc[6],0,Integer.parseInt(rs),0,i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[7])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  im = sub4+sub5+sub6+"00";
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[7]+" R"+rs+" #"+i;
                          Inst.add(new Instruction(address,oc[7],0,Integer.parseInt(rs),0,i,s)); 
			  System.out.println(s);
		  }
		  else if(sub1.equals(bn[8])){									  
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6;
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[8]+" R"+rt+" R"+rs+" #"+i;
                          Inst.add(new Instruction(address,oc[8],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
			  
		  }
		  else if(sub1.equals(bn[9])){						
			  rs = String.valueOf(Integer.parseInt(sub2,2));
			  rt = String.valueOf(Integer.parseInt(sub3,2));
			  im = sub4+sub5+sub6;
			  long l = Long.parseLong(changeSign(im),2);
			  int i = (int) l;
			  s = address+" "+oc[9]+" R"+rt+" R"+rs+" #"+i;
                          Inst.add(new Instruction(address,oc[9],0,Integer.parseInt(rs),Integer.parseInt(rt),i,s)); 
			  System.out.println(s);
		  }
	  }
	 
	  address = address+4;
	  return s;
	  
  }
  
  public void PrintInstructions(){
      int i = 0;
      while(i<Inst.size()){
          System.out.println(Inst.get(i).add+" "+Inst.get(i).opcode+" "+Inst.get(i).rd+
                         " "+Inst.get(i).rs+" "+Inst.get(i).rt+" "+Inst.get(i).offset+
                         " "+Inst.get(i).ins);
          i++;
      }
  }
  
  public String changeSign(String s){
      int i=32-s.length();
      char[] se = new char[i];
      Arrays.fill(se, s.charAt(0));

      return new String(se)+s;
  }
  
  public String convertBtToBn(byte [] btins){
	  String s1 = new String();
	  String s2;
	  int i;
	  for(i=0;i<btins.length;i++){
		  int j = btins[i] & 0xFF;
		  s2 = Integer.toBinaryString(j);
		  if(s2.length() < 8)
		  s1 = s1 + String.format("%08d", Integer.valueOf(s2));
		  else 
			  s1 = s1+ s2;
	  }
	  return s1;
  }
  
  public static void main(String args[]) throws IOException
  {
	  String s,sub1;
	  MIPSsim dis = new MIPSsim();
          try {
		  
			File file = new File(args[1]);
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			dis.binaryReader(args[0]);
			for(int i=0;i<dis.bnstr.size();i++){
				s = dis.bnstr.get(i);
				sub1 = dis.disassemble(s);
				//System.out.println(sub1);
				//bw.write(sub1);
				//bw.newLine();
			}
			
			//bw.close();
			//System.out.println("Done");
                        //System.out.println();
                       // dis.PrintInstructions();
                        //while (Inst.get(0).opcode.equals("BREAK")){
                        //dis.Fetch();
                        dis.PrintCurrentStatus(bw,0,0);
                        bw.close();
                        //}
                       //dis.PrintInstructions();
		}
	  	catch (IOException e) {
			e.printStackTrace();
		}
	  
  }
}